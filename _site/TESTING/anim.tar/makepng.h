#include <stdio.h>
#include <png.h>
#include <stdlib.h>

int makepng(char *filename, int width, int height, char *pixels);
